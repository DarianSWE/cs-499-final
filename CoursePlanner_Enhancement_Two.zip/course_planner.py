# ============================================================================
# Name        : course_planner.py
# Author      : Darian Gernand
# Version     : 1.0
# Description : Standalone Python companion script for the Course Planner
#               application. Manages course data using Python's built-in
#               sqlite3 module, replacing the flat-file CSV approach with
#               a proper relational database backend.
#
#               Key improvements over the original C++ flat-file approach:
#               - Structured schema with PRIMARY KEY and NOT NULL constraints
#               - Persistent storage across sessions (data survives program exit)
#               - Parameterized queries throughout to prevent SQL injection
#               - INSERT OR IGNORE enforces duplicate prevention at the DB level
#               - Row validation before insertion to ensure data integrity
# ============================================================================

import sqlite3
import csv
import os

# Path to the SQLite database file.
# The database is created automatically on first run if it does not exist.
DB_FILE = "courses.db"


# ============================================================================
# create_table()
# Connects to the database and creates the Courses table if it does not
# already exist. Uses CREATE TABLE IF NOT EXISTS so this function is safe
# to call on every startup without risk of overwriting existing data.
#
# Schema:
#   courseID      TEXT PRIMARY KEY  — unique identifier, enforces no duplicates
#   title         TEXT NOT NULL     — course name, required field
#   prerequisites TEXT              — comma-joined prerequisite IDs, nullable
# ============================================================================
def create_table():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Courses (
            courseID      TEXT PRIMARY KEY,
            title         TEXT NOT NULL,
            prerequisites TEXT
        )
    """)

    conn.commit()
    conn.close()


# ============================================================================
# import_csv(filename)
# Opens a CSV file and imports course data into the Courses table.
# Each row is expected to follow the format:
#   courseID,title[,prerequisite1,prerequisite2,...]
#
# Validation applied to each row:
#   - Skips rows with fewer than 2 fields with a warning
#   - Skips rows where courseID is empty or whitespace-only with a warning
#   - Uses INSERT OR IGNORE to silently skip duplicate courseIDs
#   - Strips whitespace from all fields before inserting
#
# Parameterized queries (the ? placeholders) are used exclusively to
# prevent SQL injection from file-supplied data.
#
# @param filename - path to the CSV file to import
# ============================================================================
def import_csv(filename):
    # Validate that the file exists before attempting to open it
    if not os.path.exists(filename):
        print(f'Error: File "{filename}" not found. Please check the path and try again.')
        return

    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    inserted = 0
    skipped = 0

    with open(filename, newline="", encoding="utf-8") as csvfile:
        reader = csv.reader(csvfile)

        for line_number, row in enumerate(reader, start=1):

            # Strip whitespace from all fields in the row
            row = [field.strip() for field in row]

            # Skip rows with fewer than 2 fields (missing title)
            if len(row) < 2:
                print(f"Warning: Line {line_number} skipped — fewer than 2 fields found.")
                skipped += 1
                continue

            course_id = row[0]
            title     = row[1]

            # Skip rows where courseID is empty after stripping
            if not course_id:
                print(f"Warning: Line {line_number} skipped — courseID is empty.")
                skipped += 1
                continue

            # Join any remaining fields as a comma-separated prerequisites string
            # If no prerequisites exist, store None (NULL in the database)
            prerequisites = ", ".join(row[2:]) if len(row) > 2 else None

            # INSERT OR IGNORE skips the row silently if courseID already exists,
            # enforcing the PRIMARY KEY constraint without raising an error.
            # The ? placeholders are parameterized — data is never interpreted as SQL.
            cursor.execute(
                "INSERT OR IGNORE INTO Courses (courseID, title, prerequisites) VALUES (?, ?, ?)",
                (course_id, title, prerequisites)
            )

            # cursor.rowcount is 1 if the row was inserted, 0 if it was ignored
            if cursor.rowcount == 1:
                inserted += 1
            else:
                skipped += 1

    conn.commit()
    conn.close()

    print(f"{inserted} course(s) imported successfully.")
    if skipped > 0:
        print(f"{skipped} row(s) skipped (duplicates or invalid data).")


# ============================================================================
# print_sorted()
# Retrieves all courses from the database sorted alphanumerically by
# courseID using an ORDER BY clause and prints each course's ID and title.
# ============================================================================
def print_sorted():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # ORDER BY courseID sorts alphanumerically at the database level
    cursor.execute("SELECT courseID, title FROM Courses ORDER BY courseID")
    courses = cursor.fetchall()
    conn.close()

    if not courses:
        print("No courses found. Please import a CSV file first (Option 1).")
        return

    print("\nHere is a sample schedule:")
    print("----------------------------")
    for course_id, title in courses:
        print(f"{course_id}, {title}")
    print()


# ============================================================================
# search_course(course_id)
# Searches for a course by courseID using a parameterized SELECT query
# and prints the course title and prerequisites if found.
#
# The WHERE clause uses a ? placeholder — the courseID value is passed
# separately and never concatenated into the query string, preventing
# SQL injection regardless of what the user enters.
#
# @param course_id - the courseID to search for (converted to uppercase)
# ============================================================================
def search_course(course_id):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Parameterized query — course_id is passed as a bound parameter, not
    # inserted into the SQL string directly
    cursor.execute(
        "SELECT courseID, title, prerequisites FROM Courses WHERE courseID = ?",
        (course_id,)
    )
    result = cursor.fetchone()
    conn.close()

    if not result:
        print(f'Course "{course_id}" not found.')
        return

    course_id, title, prerequisites = result

    print(f"\n{course_id}, {title}")

    # Display prerequisites, or a clear note if there are none
    if prerequisites:
        print(f"Prerequisites: {prerequisites}")
    else:
        print("Prerequisites: None")
    print()


# ============================================================================
# main()
# Entry point for the Course Planner companion script.
# Initializes the database on startup, then presents a menu loop for
# importing data and querying the database.
#
# Input validation:
#   - Empty or whitespace-only menu input re-prompts without crashing
#   - Non-numeric menu input is caught and handled gracefully
#   - Empty courseID input for option 3 is rejected with a message
# ============================================================================
def main():
    # Ensure the Courses table exists before any menu operations run
    create_table()

    print("Welcome to the Course Planner (Database Edition).")
    print()

    while True:
        print("1. Import CSV into Database.")
        print("2. Print Course List.")
        print("3. Search Course.")
        print("9. Exit")
        raw_input_val = input("What would you like to do? ").strip()

        # Validate that the input is not empty
        if not raw_input_val:
            print("Invalid input. Please enter a number.")
            print()
            continue

        # Validate that the input is a number
        if not raw_input_val.isdigit():
            print(f'"{raw_input_val}" is not a valid option.')
            print()
            continue

        choice = int(raw_input_val)

        if choice == 1:
            filename = input("Enter CSV file name: ").strip()

            # Validate that the filename is not empty
            if not filename:
                print("Error: Filename cannot be empty.")
                print()
                continue

            import_csv(filename)
            print()

        elif choice == 2:
            print_sorted()

        elif choice == 3:
            course_id = input("What course do you want to know about? ").strip()

            # Validate that the courseID input is not empty
            if not course_id:
                print("Error: Course ID cannot be empty.")
                print()
                continue

            # Convert to uppercase for consistent matching
            course_id = course_id.upper()
            search_course(course_id)

        elif choice == 9:
            print("Thank you for using the Course Planner. Goodbye.")
            break

        else:
            print(f"{choice} is not a valid option.")
            print()


# Entry point guard — ensures main() only runs when the script is
# executed directly, not when imported as a module
if __name__ == "__main__":
    main()
